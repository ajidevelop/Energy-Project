create definer = root@localhost event expirenouser
  on schedule
    every '1' MINUTE
      starts '2018-07-10 17:27:11'
  enable
do
  DELETE FROM users 
WHERE TIMESTAMPDIFF(MINUTE, user_since , NOW()) > 1 AND verified = 'N';

