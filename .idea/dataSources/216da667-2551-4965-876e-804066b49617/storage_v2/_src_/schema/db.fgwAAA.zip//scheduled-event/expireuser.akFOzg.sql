create definer = root@localhost event expireuser
  on schedule
    every '30' MINUTE
      starts '2018-07-10 17:27:11'
  enable
do
  DELETE FROM verification
WHERE TIMESTAMPDIFF(HOUR, ts_create , NOW()) > 24;

